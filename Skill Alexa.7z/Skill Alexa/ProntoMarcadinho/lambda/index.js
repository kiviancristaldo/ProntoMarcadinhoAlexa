/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');
const axios = require('axios');

var iDCliente;
var iDProfissional;
var HorariosLista;
var JSONHorarios;

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Bem vindo a skill de comunicação <lang xml:lang="en-IN">Delphi</lang> e Alexa Pronto Marcadinho. Vamos brincar de fazer um agendamento e você verá na sua aplicação VCL. Me diga seu nome.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const NomeDoClienteIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'NomeDoClienteIntent';
    },
   async handle(handlerInput) {
        let saidaFala;
        const NomeDoCliente = handlerInput.requestEnvelope.request.intent.slots.nomeDoCliente.value;
        
        const fullUrl = `http://179.232.75.196:9000/LocalizarCliente/${NomeDoCliente}`;
    //    console.log(`URL ${fullUrl}`);
        
        await axios.get(fullUrl)
        .then(async (response) => {
          //  console.log('RETORNO CONSULTA', NomeDoCliente, response.data, response)
            const data = response.data;
            iDCliente = data;
        })
        .catch((err) => {
          console.log(`ERRORRRRR: ${err.message}`);
        });
        
          
        if (iDCliente > 0) {
            saidaFala = `Olá ${NomeDoCliente}! Agora me fale o nome do Profissional, o dia e o turno que deseja?`;
        }
        else {
            saidaFala = `Olá ${NomeDoCliente}! Nunca nos vimos antes.. vou ter que te mandar embora tchau!`;
        }
        const speakOutput = saidaFala;  
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('Eu não escutei. Pode me falar seu nome?')
            .getResponse();
    }
};

const CarregarHorariosIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CarregarHorariosIntent';
    },
   async handle(handlerInput) {
        console.log('CHEGUEI NO BuscarHorariosDisponiveisIntentHandler');
        
        let saidaFala;
        let Horarios;
        
        const Dia = handlerInput.requestEnvelope.request.intent.slots.DataDoAgendamento.value;
        const Turno = handlerInput.requestEnvelope.request.intent.slots.Turno.value;
        const NomeDoProfissional = handlerInput.requestEnvelope.request.intent.slots.NomeDoProfissional.value;
        const IDTurno = handlerInput.requestEnvelope.request.intent.slots.Turno.resolutions.resolutionsPerAuthority[0].values[0].value.id;
        
        const fullUrl = `http://179.232.75.196:9000/BuscarHorariosDisponiveis/${Dia}/${IDTurno}/${NomeDoProfissional}`;
        console.log(`URL ${fullUrl}`);
        
        await axios.get(fullUrl)
        .then(async (response) => {
            console.log('RETORNO CONSULTA BuscarHorariosDisponiveis', Dia, response.data, response)
            JSONHorarios = response.data;
            console.log('----------------------');
            
            console.log(JSONHorarios.lista[0].iD);
            
            const stringDeHorarios = JSONHorarios.lista.map((item,i) =>{
            return item.horario.slice(0,2) + 'horas ';
            }) 
            
            console.log('STRING DE HORARIOS:'+stringDeHorarios);
            Horarios = stringDeHorarios;
            
        })
        .catch((err) => {
          console.log(`ERRO no Endpoint BuscarHorariosDisponiveis: ${err.message}`);
        });
          
        if (Horarios.length > 0) {
            saidaFala = `Para o dia ${Dia} no turno ${Turno} com ${NomeDoProfissional} temos os horários ${Horarios} !`; 
        }
        else {
            saidaFala = `Não achei nada para o dia ${Dia} no turno ${Turno} com ${NomeDoProfissional}. Vamos tentar novamente? Me fale o profissional, data e o turno que deseja.`;
        }
      
        const speakOutput = saidaFala;  
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('Opss, não entendi. Pode me falar o nome do profissional, a data e o turno que deseja?')
            .getResponse();
    }
};

const MarcandoHoraIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MarcandoHoraIntent';
    },
   async handle(handlerInput) {
        console.log('CHEGUEI NO MARCAR HORARIO');
        
        let saidaFala;
        let Horarios;
        
        const Horario = handlerInput.requestEnvelope.request.intent.slots.HoraDaMarcacao.value;
        
        console.log('HORARIOVALUE'+ handlerInput.requestEnvelope.request.intent.slots.HoraDaMarcacao.value);
            
        const stringDeHorariosFiltrados = JSONHorarios.lista.filter((item,i) =>{
              return item.horario === Horario+':00'; 
                
        }) 
        console.log('HORARIOS FILTRADOS',stringDeHorariosFiltrados[0]);
        console.log('ID',stringDeHorariosFiltrados[0].iD);
        const IDHorario = stringDeHorariosFiltrados[0].iD;
        

        
        const fullUrl = `http://179.232.75.196:9000/MarcarHorario/${iDCliente}/${IDHorario}`;
        console.log(`URL ${fullUrl}`);
        
        await axios.get(fullUrl)
        .then(async (response) => {
            console.log('RETORNO CONSULTA MarcandoHora', response.data, response)
            let data = response.data.statusText; 
            
            console.log('RETORNO STATUS ',data);
            
        })
        .catch((err) => {
          console.log(`ERRO no Endpoint MarcandoHora: ${err.message}`);
        });
       saidaFala = `<amazon:emotion name="excited" intensity="high">Tudo certo com teu agendamento, corre lá na aplicação <lang xml:lang="en-IN">Delphi</lang> pra ver o horário marcado por aqui!</amazon:emotion>`; 
    
        const speakOutput = saidaFala;  
        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};


const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Tu precisa de ajuda?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Tchaauu!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Desculpe, não sei nada sobre isso. Tente novamente.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        NomeDoClienteIntentHandler,
        CarregarHorariosIntentHandler,
        MarcandoHoraIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();